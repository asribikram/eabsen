<?php 
if(!isset($_SESSION['login'])) {
    header("Location: eabsen/index.php");
}
?>