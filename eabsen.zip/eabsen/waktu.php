<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waktu</title>
    <!-- Menggunakan Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid text-center" style="background-color: #E0E0E0; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">
        <h2>ABSENSI BLUD UPT ANGKUTAN KOTA BANDUNG</h2>
        <p>PORTAL ABSENSI BLUD UPT ANGKUTAN KOTA BANDUNG</p>
        <div class="card card-container" style="max-width: 800px;">
            <div class="card-body" style="background-color: red; min-height: 100px;">
                <div class="container" style="text-align: center;">
                    <br>
                    <h2 class="card-title">MOHON MAAF ABSENSI PAGI TELAT DITUTUP!</h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Menggunakan Bootstrap JS (jQuery, Popper.js, dan Bootstrap JS) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
